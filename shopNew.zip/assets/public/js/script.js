$('document').ready(function(){



	$('.addToCart').on('click',function(){

		console.log('product added to cart');
	});


});